package com.flowfree.app.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface DictionaryDao {
    @Query("SELECT * FROM dictionary_entries WHERE isDeleted = 0 ORDER BY word COLLATE NOCASE ASC")
    fun observeActiveEntries(): Flow<List<DictionaryEntry>>

    @Query("SELECT * FROM dictionary_entries WHERE isDeleted = 0")
    suspend fun getActiveEntries(): List<DictionaryEntry>

    @Query("SELECT * FROM dictionary_entries")
    suspend fun getAllEntriesIncludingDeleted(): List<DictionaryEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: DictionaryEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<DictionaryEntry>)

    @Query("UPDATE dictionary_entries SET isDeleted = 1, updatedAt = :timestamp WHERE id = :id")
    suspend fun softDelete(id: String, timestamp: Long = System.currentTimeMillis())
}

@Dao
interface DictationHistoryDao {
    @Query("SELECT * FROM dictation_history ORDER BY createdAt DESC LIMIT 100")
    fun observeRecent(): Flow<List<DictationHistoryEntry>>

    @Insert
    suspend fun insert(entry: DictationHistoryEntry)

    @Query("DELETE FROM dictation_history")
    suspend fun clearAll()
}

@Database(
    entities = [DictionaryEntry::class, DictationHistoryEntry::class],
    version = 1,
    exportSchema = false
)
abstract class FlowFreeDatabase : RoomDatabase() {
    abstract fun dictionaryDao(): DictionaryDao
    abstract fun historyDao(): DictationHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: FlowFreeDatabase? = null

        fun getInstance(context: Context): FlowFreeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FlowFreeDatabase::class.java,
                    "flowfree_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
