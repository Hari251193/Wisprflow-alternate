package com.flowfree.app.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FlowAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: FlowAccessibilityService? = null
            private set

        @Volatile
        var lastActivePackage: String = ""
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (!pkg.isNullOrBlank() && pkg != packageName) {
            lastActivePackage = pkg
        }
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
    }

    fun insertTextIntoActiveField(text: String): Boolean {
        val focusedNode = findFocusedEditableNode() ?: return false

        return try {
            val currentText = focusedNode.text?.toString().orEmpty()
            val selStart = focusedNode.textSelectionStart.coerceIn(0, currentText.length)
            val selEnd = focusedNode.textSelectionEnd.coerceIn(0, currentText.length)
            val start = minOf(selStart, selEnd)
            val end = maxOf(selStart, selEnd)

            // Add a leading space if inserting right after a non-whitespace character
            val needsSpace = start > 0 && !currentText[start - 1].isWhitespace()
            val insertPayload = if (needsSpace) " $text" else text

            val updatedText = buildString {
                append(currentText.substring(0, start))
                append(insertPayload)
                append(currentText.substring(end))
            }

            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updatedText)
            }
            val setOk = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

            if (setOk) {
                val newCursor = (start + insertPayload.length).coerceAtMost(updatedText.length)
                val selArgs = Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, newCursor)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, newCursor)
                }
                focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)
                true
            } else {
                // Fallback: copy to clipboard and trigger ACTION_PASTE
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("FlowFree Dictation", insertPayload))
                focusedNode.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun findFocusedEditableNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val inputFocused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (inputFocused != null && inputFocused.isEditable) {
            return inputFocused
        }
        return findFirstEditableRecursive(root)
    }

    private fun findFirstEditableRecursive(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableRecursive(node.getChild(i))
            if (found != null) return found
        }
        return null
    }
}
