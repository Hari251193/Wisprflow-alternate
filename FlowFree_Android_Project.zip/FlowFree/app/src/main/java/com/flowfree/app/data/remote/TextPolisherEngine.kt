package com.flowfree.app.data.remote

import com.flowfree.app.data.local.DictionaryEntry
import com.flowfree.app.data.model.AppSettings
import com.flowfree.app.data.model.LlmProvider
import com.flowfree.app.data.model.WritingTone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class TextPolisherEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun polish(
        rawText: String,
        settings: AppSettings,
        dictionary: List<DictionaryEntry>
    ): String {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return ""

        // First apply deterministic dictionary alias replacements
        val preCorrected = applyDictionaryAliases(trimmed, dictionary)

        val polished = when (settings.llmProvider) {
            LlmProvider.LOCAL_RULES -> localCleanup(preCorrected, settings.writingTone)
            LlmProvider.GEMINI_FREE -> {
                if (settings.geminiApiKey.isBlank()) {
                    localCleanup(preCorrected, settings.writingTone)
                } else {
                    runCatching {
                        callGemini(
                            text = preCorrected,
                            apiKey = settings.geminiApiKey,
                            modelId = settings.geminiModelId,
                            tone = settings.writingTone,
                            dictionary = dictionary
                        )
                    }.getOrElse { localCleanup(preCorrected, settings.writingTone) }
                }
            }
            LlmProvider.GROQ_FREE -> {
                if (settings.groqApiKey.isBlank()) {
                    localCleanup(preCorrected, settings.writingTone)
                } else {
                    runCatching {
                        callOpenAiCompatible(
                            endpoint = "https://api.groq.com/openai/v1/chat/completions",
                            apiKey = settings.groqApiKey,
                            modelId = settings.groqModelId,
                            text = preCorrected,
                            tone = settings.writingTone,
                            dictionary = dictionary
                        )
                    }.getOrElse { localCleanup(preCorrected, settings.writingTone) }
                }
            }
            LlmProvider.OPENROUTER_FREE -> {
                if (settings.openRouterApiKey.isBlank()) {
                    localCleanup(preCorrected, settings.writingTone)
                } else {
                    runCatching {
                        callOpenAiCompatible(
                            endpoint = "https://openrouter.ai/api/v1/chat/completions",
                            apiKey = settings.openRouterApiKey,
                            modelId = settings.openRouterModelId,
                            text = preCorrected,
                            tone = settings.writingTone,
                            dictionary = dictionary,
                            extraHeaders = mapOf("HTTP-Referer" to "https://flowfree.app", "X-Title" to "FlowFree")
                        )
                    }.getOrElse { localCleanup(preCorrected, settings.writingTone) }
                }
            }
        }

        // Final deterministic pass to guarantee custom dictionary casing/spelling
        return applyDictionaryAliases(polished, dictionary)
    }

    fun applyDictionaryAliases(text: String, dictionary: List<DictionaryEntry>): String {
        var result = text
        for (entry in dictionary) {
            if (entry.isDeleted || entry.word.isBlank()) continue
            val aliases = entry.aliases
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            for (alias in aliases) {
                val regex = Regex("\\b${Regex.escape(alias)}\\b", RegexOption.IGNORE_CASE)
                result = regex.replace(result, Regex.escapeReplacement(entry.word))
            }
            // Also enforce exact casing of the canonical word if it appears case-insensitively
            val exactWordRegex = Regex("\\b${Regex.escape(entry.word)}\\b", RegexOption.IGNORE_CASE)
            result = exactWordRegex.replace(result, Regex.escapeReplacement(entry.word))
        }
        return result
    }

    fun localCleanup(text: String, tone: WritingTone): String {
        var cleaned = text
            // Remove common filler words
            .replace(Regex("\\b(um+|uh+|er+|ah+|hmm+)\\b,?\\s*", RegexOption.IGNORE_CASE), "")
            // Handle simple spoken self-corrections like "at 2 actually 3" or "at 2 no wait 3"
            .replace(Regex("\\b\\S+\\s+(?:actually|no wait|sorry I mean)\\s+", RegexOption.IGNORE_CASE), "")
            // Collapse extra spaces
            .replace(Regex("\\s{2,}"), " ")
            .trim()

        if (cleaned.isNotEmpty()) {
            cleaned = cleaned.replaceFirstChar { it.uppercaseChar() }
            if (cleaned.last() !in listOf('.', '!', '?')) {
                cleaned += "."
            }
        }

        if (tone == WritingTone.BULLET_NOTES && cleaned.contains(", and ")) {
            val parts = cleaned.removeSuffix(".").split(Regex(",\\s+(?:and\\s+)?"))
            if (parts.size >= 3) {
                cleaned = parts.joinToString("\n") { "- ${it.trim().replaceFirstChar { c -> c.uppercaseChar() }}" }
            }
        }
        return cleaned
    }

    private fun buildSystemPrompt(tone: WritingTone, dictionary: List<DictionaryEntry>): String {
        val vocabLines = dictionary
            .filter { !it.isDeleted && it.word.isNotBlank() }
            .take(150)
            .joinToString(", ") { entry ->
                if (entry.aliases.isNotBlank()) "${entry.word} (often misheard as: ${entry.aliases})"
                else entry.word
            }

        return buildString {
            appendLine("You are an expert voice-to-text dictation editor like Wispr Flow.")
            appendLine("Your job is to turn raw speech transcripts into clean, ready-to-send text.")
            appendLine("Rules:")
            appendLine("1. ${tone.instruction}")
            appendLine("2. Remove filler words (um, uh, ah, you know) and false starts.")
            appendLine("3. Apply mid-sentence self-corrections (e.g., 'let's meet at 2, actually 3' -> 'Let's meet at 3.').")
            appendLine("4. Format spoken numbered lists or bullet points cleanly when appropriate.")
            appendLine("5. Output ONLY the final polished text—no quotes, no explanations, no preamble.")
            if (vocabLines.isNotBlank()) {
                appendLine("6. Personal Dictionary (always prefer these exact spellings): $vocabLines")
            }
        }
    }

    private suspend fun callGemini(
        text: String,
        apiKey: String,
        modelId: String,
        tone: WritingTone,
        dictionary: List<DictionaryEntry>
    ): String = withContext(Dispatchers.IO) {
        val systemPrompt = buildSystemPrompt(tone, dictionary)
        val payload = buildJsonObject {
            put("systemInstruction", buildJsonObject {
                putJsonArray("parts") {
                    addJsonObject { put("text", systemPrompt) }
                }
            })
            putJsonArray("contents") {
                addJsonObject {
                    put("role", "user")
                    putJsonArray("parts") {
                        addJsonObject { put("text", text) }
                    }
                }
            }
            put("generationConfig", buildJsonObject {
                put("temperature", 0.1)
            })
        }.toString()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini API error (${response.code}): $body")
            }
            val root = json.parseToJsonElement(body).jsonObject
            val candidateText = root["candidates"]?.jsonArray
                ?.firstOrNull()?.jsonObject
                ?.get("content")?.jsonObject
                ?.get("parts")?.jsonArray
                ?.firstOrNull()?.jsonObject
                ?.get("text")?.jsonPrimitive?.content
            candidateText?.trim()?.ifEmpty { text } ?: text
        }
    }

    private suspend fun callOpenAiCompatible(
        endpoint: String,
        apiKey: String,
        modelId: String,
        text: String,
        tone: WritingTone,
        dictionary: List<DictionaryEntry>,
        extraHeaders: Map<String, String> = emptyMap()
    ): String = withContext(Dispatchers.IO) {
        val systemPrompt = buildSystemPrompt(tone, dictionary)
        val payload = buildJsonObject {
            put("model", modelId)
            put("temperature", 0.1)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "system")
                    put("content", systemPrompt)
                }
                addJsonObject {
                    put("role", "user")
                    put("content", text)
                }
            }
        }.toString()

        val requestBuilder = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(payload.toRequestBody("application/json".toMediaType()))

        extraHeaders.forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        client.newCall(requestBuilder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("LLM API error (${response.code}): $body")
            }
            val root = json.parseToJsonElement(body).jsonObject
            val reply = root["choices"]?.jsonArray
                ?.firstOrNull()?.jsonObject
                ?.get("message")?.jsonObject
                ?.get("content")?.jsonPrimitive?.content
            reply?.trim()?.ifEmpty { text } ?: text
        }
    }
}
