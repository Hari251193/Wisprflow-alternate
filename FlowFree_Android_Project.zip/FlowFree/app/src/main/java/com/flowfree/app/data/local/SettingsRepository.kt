package com.flowfree.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.flowfree.app.data.model.AppSettings
import com.flowfree.app.data.model.AsrProvider
import com.flowfree.app.data.model.BubbleStyle
import com.flowfree.app.data.model.LlmProvider
import com.flowfree.app.data.model.WritingTone
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "flowfree_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val ASR_PROVIDER = stringPreferencesKey("asr_provider")
        val LLM_PROVIDER = stringPreferencesKey("llm_provider")
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val GEMINI_MODEL_ID = stringPreferencesKey("gemini_model_id")
        val GROQ_API_KEY = stringPreferencesKey("groq_api_key")
        val GROQ_MODEL_ID = stringPreferencesKey("groq_model_id")
        val OPENROUTER_API_KEY = stringPreferencesKey("openrouter_api_key")
        val OPENROUTER_MODEL_ID = stringPreferencesKey("openrouter_model_id")
        val WRITING_TONE = stringPreferencesKey("writing_tone")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val AUTO_SYNC_DRIVE = booleanPreferencesKey("auto_sync_drive")
        val LAST_SYNC_TIMESTAMP = longPreferencesKey("last_sync_timestamp")
        val DRIVE_ACCOUNT_EMAIL = stringPreferencesKey("drive_account_email")
        val LAST_SYNC_STATUS = stringPreferencesKey("last_sync_status")
        val BUBBLE_STYLE = stringPreferencesKey("bubble_style")
        val BUBBLE_SIZE_DP = intPreferencesKey("bubble_size_dp")
        val BUBBLE_IDLE_OPACITY = floatPreferencesKey("bubble_idle_opacity")
        val BUBBLE_COLOR_HEX = stringPreferencesKey("bubble_color_hex")
        val BUBBLE_SNAP_TO_EDGE = booleanPreferencesKey("bubble_snap_to_edge")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            asrProvider = prefs[Keys.ASR_PROVIDER]?.let {
                runCatching { AsrProvider.valueOf(it) }.getOrNull()
            } ?: AsrProvider.ANDROID_ON_DEVICE,
            llmProvider = prefs[Keys.LLM_PROVIDER]?.let {
                runCatching { LlmProvider.valueOf(it) }.getOrNull()
            } ?: LlmProvider.LOCAL_RULES,
            geminiApiKey = prefs[Keys.GEMINI_API_KEY] ?: "",
            geminiModelId = prefs[Keys.GEMINI_MODEL_ID] ?: LlmProvider.GEMINI_FREE.defaultModelId,
            groqApiKey = prefs[Keys.GROQ_API_KEY] ?: "",
            groqModelId = prefs[Keys.GROQ_MODEL_ID] ?: LlmProvider.GROQ_FREE.defaultModelId,
            openRouterApiKey = prefs[Keys.OPENROUTER_API_KEY] ?: "",
            openRouterModelId = prefs[Keys.OPENROUTER_MODEL_ID] ?: LlmProvider.OPENROUTER_FREE.defaultModelId,
            writingTone = prefs[Keys.WRITING_TONE]?.let {
                runCatching { WritingTone.valueOf(it) }.getOrNull()
            } ?: WritingTone.NATURAL,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en-IN",
            autoSyncDrive = prefs[Keys.AUTO_SYNC_DRIVE] ?: true,
            lastSyncTimestamp = prefs[Keys.LAST_SYNC_TIMESTAMP] ?: 0L,
            driveAccountEmail = prefs[Keys.DRIVE_ACCOUNT_EMAIL] ?: "",
            lastSyncStatus = prefs[Keys.LAST_SYNC_STATUS] ?: "Not synced yet",
            bubbleStyle = prefs[Keys.BUBBLE_STYLE]?.let {
                runCatching { BubbleStyle.valueOf(it) }.getOrNull()
            } ?: BubbleStyle.COMPACT_DOT,
            bubbleSizeDp = prefs[Keys.BUBBLE_SIZE_DP] ?: 28,
            bubbleIdleOpacity = prefs[Keys.BUBBLE_IDLE_OPACITY] ?: 0.65f,
            bubbleColorHex = prefs[Keys.BUBBLE_COLOR_HEX] ?: "#38BDF8",
            bubbleSnapToEdge = prefs[Keys.BUBBLE_SNAP_TO_EDGE] ?: true
        )
    }

    suspend fun getCurrentSettings(): AppSettings = settingsFlow.first()

    suspend fun updateAsrProvider(provider: AsrProvider) {
        context.dataStore.edit { it[Keys.ASR_PROVIDER] = provider.name }
    }

    suspend fun updateLlmProvider(provider: LlmProvider) {
        context.dataStore.edit { it[Keys.LLM_PROVIDER] = provider.name }
    }

    suspend fun updateGeminiConfig(apiKey: String, modelId: String) {
        context.dataStore.edit {
            it[Keys.GEMINI_API_KEY] = apiKey.trim()
            it[Keys.GEMINI_MODEL_ID] = modelId.trim().ifEmpty { LlmProvider.GEMINI_FREE.defaultModelId }
        }
    }

    suspend fun updateGroqConfig(apiKey: String, modelId: String) {
        context.dataStore.edit {
            it[Keys.GROQ_API_KEY] = apiKey.trim()
            it[Keys.GROQ_MODEL_ID] = modelId.trim().ifEmpty { LlmProvider.GROQ_FREE.defaultModelId }
        }
    }

    suspend fun updateOpenRouterConfig(apiKey: String, modelId: String) {
        context.dataStore.edit {
            it[Keys.OPENROUTER_API_KEY] = apiKey.trim()
            it[Keys.OPENROUTER_MODEL_ID] = modelId.trim().ifEmpty { LlmProvider.OPENROUTER_FREE.defaultModelId }
        }
    }

    suspend fun updateWritingTone(tone: WritingTone) {
        context.dataStore.edit { it[Keys.WRITING_TONE] = tone.name }
    }

    suspend fun updateLanguageCode(code: String) {
        context.dataStore.edit { it[Keys.LANGUAGE_CODE] = code.trim().ifEmpty { "en-IN" } }
    }

    suspend fun updateAutoSyncDrive(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SYNC_DRIVE] = enabled }
    }

    suspend fun updateBubbleStyle(style: BubbleStyle) {
        context.dataStore.edit { it[Keys.BUBBLE_STYLE] = style.name }
    }

    suspend fun updateBubbleSizeDp(sizeDp: Int) {
        context.dataStore.edit { it[Keys.BUBBLE_SIZE_DP] = sizeDp.coerceIn(18, 60) }
    }

    suspend fun updateBubbleIdleOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.BUBBLE_IDLE_OPACITY] = opacity.coerceIn(0.15f, 1.0f) }
    }

    suspend fun updateBubbleColorHex(hex: String) {
        context.dataStore.edit { it[Keys.BUBBLE_COLOR_HEX] = hex }
    }

    suspend fun updateBubbleSnapToEdge(snap: Boolean) {
        context.dataStore.edit { it[Keys.BUBBLE_SNAP_TO_EDGE] = snap }
    }

    suspend fun updateSyncMetadata(email: String?, timestamp: Long?, status: String) {
        context.dataStore.edit {
            if (email != null) it[Keys.DRIVE_ACCOUNT_EMAIL] = email
            if (timestamp != null) it[Keys.LAST_SYNC_TIMESTAMP] = timestamp
            it[Keys.LAST_SYNC_STATUS] = status
        }
    }
}
