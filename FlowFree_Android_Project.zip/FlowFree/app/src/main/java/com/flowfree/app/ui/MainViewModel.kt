package com.flowfree.app.ui

import android.app.Application
import android.app.PendingIntent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.flowfree.app.FlowFreeApplication
import com.flowfree.app.data.local.DictationHistoryEntry
import com.flowfree.app.data.local.DictionaryEntry
import com.flowfree.app.data.model.AppSettings
import com.flowfree.app.data.model.AsrProvider
import com.flowfree.app.data.model.BubbleStyle
import com.flowfree.app.data.model.LlmProvider
import com.flowfree.app.data.model.WritingTone
import com.flowfree.app.data.remote.TextPolisherEngine
import com.flowfree.app.data.sync.DictionarySyncWorker
import com.flowfree.app.data.sync.SyncResult
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FlowFreeApplication
    private val dictionaryDao = app.database.dictionaryDao()
    private val historyDao = app.database.historyDao()
    private val settingsRepo = app.settingsRepository
    private val driveSync = app.driveSyncManager
    private val polisher = TextPolisherEngine()

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val dictionaryEntries: StateFlow<List<DictionaryEntry>> = dictionaryDao.observeActiveEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentHistory: StateFlow<List<DictationHistoryEntry>> = historyDao.observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _driveConsentEvent = MutableSharedFlow<PendingIntent>()
    val driveConsentEvent = _driveConsentEvent.asSharedFlow()

    private val _uiMessage = MutableSharedFlow<String>()
    val uiMessage = _uiMessage.asSharedFlow()

    fun addOrUpdateWord(word: String, aliases: String, category: String, existingId: String? = null) {
        val cleanWord = word.trim()
        if (cleanWord.isEmpty()) return

        viewModelScope.launch {
            val entry = DictionaryEntry(
                id = existingId ?: java.util.UUID.randomUUID().toString(),
                word = cleanWord,
                aliases = aliases.trim(),
                category = category.trim().ifEmpty { "General" },
                updatedAt = System.currentTimeMillis(),
                isDeleted = false
            )
            dictionaryDao.upsert(entry)
            if (settings.value.autoSyncDrive) {
                DictionarySyncWorker.triggerImmediateSync(app)
            }
        }
    }

    fun deleteWord(id: String) {
        viewModelScope.launch {
            dictionaryDao.softDelete(id)
            if (settings.value.autoSyncDrive) {
                DictionarySyncWorker.triggerImmediateSync(app)
            }
        }
    }

    fun syncDriveNow() {
        if (_isSyncing.value) return
        viewModelScope.launch {
            _isSyncing.value = true
            when (val res = driveSync.authorizeAndSync()) {
                is SyncResult.Success -> _uiMessage.emit("Synced ${res.mergedCount} dictionary words with Google Drive.")
                is SyncResult.NeedsResolution -> _driveConsentEvent.emit(res.pendingIntentSender)
                is SyncResult.Failure -> _uiMessage.emit("Drive sync failed: ${res.message}")
            }
            _isSyncing.value = false
        }
    }

    fun completeDriveSyncWithToken(accessToken: String) {
        viewModelScope.launch {
            _isSyncing.value = true
            when (val res = driveSync.syncWithToken(accessToken)) {
                is SyncResult.Success -> _uiMessage.emit("Google Drive connected! Synced ${res.mergedCount} words.")
                is SyncResult.Failure -> _uiMessage.emit("Drive sync failed: ${res.message}")
                is SyncResult.NeedsResolution -> Unit
            }
            _isSyncing.value = false
        }
    }

    fun setAsrProvider(provider: AsrProvider) {
        viewModelScope.launch { settingsRepo.updateAsrProvider(provider) }
    }

    fun setLlmProvider(provider: LlmProvider) {
        viewModelScope.launch { settingsRepo.updateLlmProvider(provider) }
    }

    fun saveGeminiConfig(apiKey: String, modelId: String) {
        viewModelScope.launch {
            settingsRepo.updateGeminiConfig(apiKey, modelId)
            _uiMessage.emit("Gemini settings saved.")
        }
    }

    fun saveGroqConfig(apiKey: String, modelId: String) {
        viewModelScope.launch {
            settingsRepo.updateGroqConfig(apiKey, modelId)
            _uiMessage.emit("Groq settings saved.")
        }
    }

    fun saveOpenRouterConfig(apiKey: String, modelId: String) {
        viewModelScope.launch {
            settingsRepo.updateOpenRouterConfig(apiKey, modelId)
            _uiMessage.emit("OpenRouter settings saved.")
        }
    }

    fun setWritingTone(tone: WritingTone) {
        viewModelScope.launch { settingsRepo.updateWritingTone(tone) }
    }

    fun setLanguageCode(code: String) {
        viewModelScope.launch { settingsRepo.updateLanguageCode(code) }
    }

    fun setAutoSyncDrive(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.updateAutoSyncDrive(enabled)
            if (enabled) DictionarySyncWorker.triggerImmediateSync(app)
        }
    }

    fun setBubbleStyle(style: BubbleStyle) {
        viewModelScope.launch { settingsRepo.updateBubbleStyle(style) }
    }

    fun setBubbleSizeDp(sizeDp: Int) {
        viewModelScope.launch { settingsRepo.updateBubbleSizeDp(sizeDp) }
    }

    fun setBubbleIdleOpacity(opacity: Float) {
        viewModelScope.launch { settingsRepo.updateBubbleIdleOpacity(opacity) }
    }

    fun setBubbleColorHex(hex: String) {
        viewModelScope.launch { settingsRepo.updateBubbleColorHex(hex) }
    }

    fun setBubbleSnapToEdge(snap: Boolean) {
        viewModelScope.launch { settingsRepo.updateBubbleSnapToEdge(snap) }
    }

    fun clearHistory() {
        viewModelScope.launch { historyDao.clearAll() }
    }

    fun testPolishText(rawInput: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val dict = dictionaryDao.getActiveEntries()
            val result = polisher.polish(rawInput, settings.value, dict)
            onResult(result)
        }
    }
}
