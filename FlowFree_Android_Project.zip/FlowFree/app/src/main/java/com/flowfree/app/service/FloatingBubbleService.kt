package com.flowfree.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.flowfree.app.FlowFreeApplication
import com.flowfree.app.data.local.DictationHistoryEntry
import com.flowfree.app.data.model.AppSettings
import com.flowfree.app.data.model.AsrProvider
import com.flowfree.app.data.model.BubbleStyle
import com.flowfree.app.data.remote.AndroidSpeechRecognizerHelper
import com.flowfree.app.data.remote.GroqWhisperClient
import com.flowfree.app.data.remote.TextPolisherEngine
import com.flowfree.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class FloatingBubbleService : Service() {

    companion object {
        private const val CHANNEL_ID = "flowfree_bubble_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.flowfree.app.STOP_BUBBLE"

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private enum class BubbleState { IDLE, LISTENING, PROCESSING }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private lateinit var bubbleContainer: LinearLayout
    private lateinit var bubbleLabel: TextView
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val speechHelper by lazy { AndroidSpeechRecognizerHelper(this) }
    private val groqWhisperClient by lazy { GroqWhisperClient() }
    private val polisherEngine by lazy { TextPolisherEngine() }
    private val wavRecorder by lazy { WavAudioRecorder() }

    private var state = BubbleState.IDLE
    private var currentSettings = AppSettings()
    private var activeDictationJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        setupFloatingBubble()
        observeSettingsLive()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        activeDictationJob?.cancel()
        serviceScope.cancel()
        if (::bubbleContainer.isInitialized) {
            runCatching { windowManager.removeView(bubbleContainer) }
        }
    }

    private fun observeSettingsLive() {
        val app = application as FlowFreeApplication
        serviceScope.launch {
            app.settingsRepository.settingsFlow.collect { settings ->
                currentSettings = settings
                applyAppearance(state, null)
            }
        }
    }

    private fun setupFloatingBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        bubbleLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
        }

        bubbleContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            elevation = 14f
            addView(bubbleLabel)
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(320)
        }

        windowManager.addView(bubbleContainer, layoutParams)
        attachTouchAndDragListener(bubbleContainer)
        applyAppearance(BubbleState.IDLE, null)
    }

    private fun applyAppearance(newState: BubbleState, customLabel: String?) {
        state = newState
        if (!::bubbleContainer.isInitialized) return

        val accentColor = runCatching {
            Color.parseColor(currentSettings.bubbleColorHex)
        }.getOrDefault(Color.parseColor("#38BDF8"))

        val isIdleDot = newState == BubbleState.IDLE &&
            currentSettings.bubbleStyle == BubbleStyle.COMPACT_DOT

        if (isIdleDot) {
            val dotPx = dp(currentSettings.bubbleSizeDp)
            bubbleLabel.text = ""
            bubbleLabel.visibility = View.GONE
            bubbleContainer.alpha = currentSettings.bubbleIdleOpacity
            bubbleContainer.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accentColor)
                setStroke(dp(2), Color.argb(200, 255, 255, 255))
            }
            layoutParams.width = dotPx
            layoutParams.height = dotPx
        } else {
            bubbleLabel.visibility = View.VISIBLE
            bubbleLabel.text = customLabel ?: when (newState) {
                BubbleState.IDLE -> "🎙 Flow"
                BubbleState.LISTENING -> "● Listening..."
                BubbleState.PROCESSING -> "✨ Polishing..."
            }
            bubbleLabel.setPadding(dp(14), dp(8), dp(14), dp(8))
            bubbleContainer.alpha = if (newState == BubbleState.IDLE) currentSettings.bubbleIdleOpacity else 1.0f

            val strokeColor = when (newState) {
                BubbleState.IDLE -> accentColor
                BubbleState.LISTENING -> Color.parseColor("#F43F5E")
                BubbleState.PROCESSING -> Color.parseColor("#A855F7")
            }
            bubbleContainer.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#18181B"))
                setStroke(dp(2), strokeColor)
            }
            layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
        }

        runCatching { windowManager.updateViewLayout(bubbleContainer, layoutParams) }
    }

    private fun attachTouchAndDragListener(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        moved = true
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        windowManager.updateViewLayout(bubbleContainer, layoutParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        onBubbleTapped()
                    } else if (currentSettings.bubbleSnapToEdge) {
                        snapToNearestEdge()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun snapToNearestEdge() {
        val screenWidth = resources.displayMetrics.widthPixels
        val viewWidth = bubbleContainer.width.coerceAtLeast(dp(currentSettings.bubbleSizeDp))
        val center = layoutParams.x + viewWidth / 2
        val margin = dp(8)
        layoutParams.x = if (center < screenWidth / 2) {
            margin
        } else {
            screenWidth - viewWidth - margin
        }
        runCatching { windowManager.updateViewLayout(bubbleContainer, layoutParams) }
    }

    private fun onBubbleTapped() {
        when (state) {
            BubbleState.IDLE -> startDictation()
            BubbleState.LISTENING -> stopGroqRecordingIfActive()
            BubbleState.PROCESSING -> Unit
        }
    }

    private fun startDictation() {
        val app = application as FlowFreeApplication
        activeDictationJob = serviceScope.launch {
            val settings = app.settingsRepository.getCurrentSettings()
            val dictionary = app.database.dictionaryDao().getActiveEntries()

            applyAppearance(BubbleState.LISTENING, "● Listening...")

            try {
                val rawTranscript = when (settings.asrProvider) {
                    AsrProvider.ANDROID_ON_DEVICE -> {
                        speechHelper.transcribeLive(settings.languageCode) { partial ->
                            applyAppearance(BubbleState.LISTENING, "● ${partial.takeLast(18)}")
                        }
                    }
                    AsrProvider.GROQ_WHISPER_TURBO -> {
                        wavRecorder.start(this)
                        kotlinx.coroutines.awaitCancellation()
                    }
                }

                if (rawTranscript.isBlank()) {
                    applyAppearance(BubbleState.IDLE, null)
                    return@launch
                }

                processAndInsert(rawTranscript, settings, dictionary)
            } catch (_: kotlinx.coroutines.CancellationException) {
                if (settings.asrProvider == AsrProvider.GROQ_WHISPER_TURBO && state == BubbleState.PROCESSING) {
                    try {
                        val wavFile = File(cacheDir, "flowfree_recording.wav")
                        wavRecorder.stopAndWriteWav(wavFile)
                        val dictHint = dictionary.joinToString(", ") { it.word }
                        val raw = groqWhisperClient.transcribeWav(
                            wavFile = wavFile,
                            apiKey = settings.groqApiKey,
                            languageCode = settings.languageCode,
                            dictionaryPrompt = dictHint
                        )
                        if (raw.isNotBlank()) {
                            processAndInsert(raw, settings, dictionary)
                        } else {
                            applyAppearance(BubbleState.IDLE, null)
                        }
                    } catch (err: Exception) {
                        showToast(err.message ?: "Transcription failed")
                        applyAppearance(BubbleState.IDLE, null)
                    }
                } else {
                    applyAppearance(BubbleState.IDLE, null)
                }
            } catch (e: Exception) {
                showToast(e.message ?: "Speech error")
                applyAppearance(BubbleState.IDLE, null)
            }
        }
    }

    private fun stopGroqRecordingIfActive() {
        val app = application as FlowFreeApplication
        serviceScope.launch {
            val settings = app.settingsRepository.getCurrentSettings()
            if (settings.asrProvider == AsrProvider.GROQ_WHISPER_TURBO) {
                applyAppearance(BubbleState.PROCESSING, "✨ Polishing...")
                activeDictationJob?.cancel()
            }
        }
    }

    private suspend fun processAndInsert(
        rawTranscript: String,
        settings: AppSettings,
        dictionary: List<com.flowfree.app.data.local.DictionaryEntry>
    ) {
        val app = application as FlowFreeApplication
        applyAppearance(BubbleState.PROCESSING, "✨ Polishing...")

        val polished = withContext(Dispatchers.Default) {
            polisherEngine.polish(rawTranscript, settings, dictionary)
        }

        val accessibility = FlowAccessibilityService.instance
        val inserted = accessibility?.insertTextIntoActiveField(polished) ?: false

        if (!inserted) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("FlowFree", polished))
            showToast("Copied to clipboard (enable Accessibility for auto-paste)")
        }

        app.database.historyDao().insert(
            DictationHistoryEntry(
                rawTranscript = rawTranscript,
                polishedText = polished,
                asrUsed = settings.asrProvider.displayName,
                llmUsed = settings.llmProvider.displayName,
                targetAppPackage = FlowAccessibilityService.lastActivePackage
            )
        )

        applyAppearance(BubbleState.IDLE, null)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FlowFree Floating Mic",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating dictation bubble active across apps"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FlowFree Bubble Active")
            .setContentText("Tap the floating dot anywhere to dictate")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }
}
