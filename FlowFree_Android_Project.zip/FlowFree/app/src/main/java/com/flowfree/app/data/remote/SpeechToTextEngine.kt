package com.flowfree.app.data.remote

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class AndroidSpeechRecognizerHelper(private val context: Context) {

    suspend fun transcribeLive(languageCode: String, onPartialResult: (String) -> Unit): String =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    cont.resumeWithException(IllegalStateException("Speech recognition is not available on this device."))
                    return@suspendCancellableCoroutine
                }

                val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }

                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}

                    override fun onError(error: Int) {
                        recognizer.destroy()
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> ""
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ""
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission missing"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "Network error (enable offline speech pack in Android Settings or switch to Groq Whisper)"
                            else -> "Speech recognizer error ($error)"
                        }
                        if (msg.isEmpty() && cont.isActive) {
                            cont.resume("")
                        } else if (cont.isActive) {
                            cont.resumeWithException(IllegalStateException(msg))
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull().orEmpty()
                        recognizer.destroy()
                        if (cont.isActive) cont.resume(text)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) onPartialResult(partial)
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                cont.invokeOnCancellation {
                    recognizer.stopListening()
                    recognizer.destroy()
                }

                recognizer.startListening(intent)
            }
        }
}

class GroqWhisperClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun transcribeWav(
        wavFile: File,
        apiKey: String,
        languageCode: String,
        dictionaryPrompt: String = ""
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            throw IllegalArgumentException("Groq API key is missing. Add your free key in Models or switch to Android Built-in Speech.")
        }

        val lang = languageCode.substringBefore("-").lowercase().ifBlank { "en" }
        val bodyBuilder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                wavFile.name,
                wavFile.asRequestBody("audio/wav".toMediaType())
            )
            .addFormDataPart("model", "whisper-large-v3-turbo")
            .addFormDataPart("language", lang)
            .addFormDataPart("response_format", "json")

        if (dictionaryPrompt.isNotBlank()) {
            bodyBuilder.addFormDataPart("prompt", dictionaryPrompt.take(400))
        }

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/audio/transcriptions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(bodyBuilder.build())
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Groq Whisper error (${response.code}): $responseBody")
            }
            val parsed = json.parseToJsonElement(responseBody).jsonObject
            parsed["text"]?.jsonPrimitive?.content.orEmpty().trim()
        }
    }
}
