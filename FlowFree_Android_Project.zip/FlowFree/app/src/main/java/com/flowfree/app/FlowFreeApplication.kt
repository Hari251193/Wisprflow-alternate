package com.flowfree.app

import android.app.Application
import com.flowfree.app.data.local.FlowFreeDatabase
import com.flowfree.app.data.local.SettingsRepository
import com.flowfree.app.data.sync.DictionarySyncWorker
import com.flowfree.app.data.sync.GoogleDriveSyncManager

class FlowFreeApplication : Application() {
    val database: FlowFreeDatabase by lazy { FlowFreeDatabase.getInstance(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
    val driveSyncManager: GoogleDriveSyncManager by lazy {
        GoogleDriveSyncManager(this, database.dictionaryDao(), settingsRepository)
    }

    override fun onCreate() {
        super.onCreate()
        DictionarySyncWorker.schedulePeriodicSync(this)
    }
}
