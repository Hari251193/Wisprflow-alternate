package com.flowfree.app.data.sync

import android.content.Context
import com.flowfree.app.data.local.DictionaryDao
import com.flowfree.app.data.local.DictionaryEntry
import com.flowfree.app.data.local.SettingsRepository
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

@Serializable
data class DictionarySyncPayload(
    val version: Int = 1,
    val syncedAt: Long = System.currentTimeMillis(),
    val entries: List<DictionaryEntry>
)

sealed class SyncResult {
    data class Success(val mergedCount: Int) : SyncResult()
    data class NeedsResolution(val pendingIntentSender: android.app.PendingIntent) : SyncResult()
    data class Failure(val message: String) : SyncResult()
}

class GoogleDriveSyncManager(
    private val context: Context,
    private val dictionaryDao: DictionaryDao,
    private val settingsRepository: SettingsRepository
) {
    companion object {
        private const val DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
        private const val DICTIONARY_FILENAME = "flowfree_dictionary.json"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
    }

    suspend fun authorizeAndSync(): SyncResult = withContext(Dispatchers.IO) {
        val authResult = requestDriveToken()
        when (authResult) {
            is TokenResult.NeedsConsent -> SyncResult.NeedsResolution(authResult.pendingIntent)
            is TokenResult.Error -> {
                settingsRepository.updateSyncMetadata(null, null, "Sync paused: ${authResult.message}")
                SyncResult.Failure(authResult.message)
            }
            is TokenResult.Success -> syncWithToken(authResult.accessToken)
        }
    }

    suspend fun syncWithToken(accessToken: String): SyncResult = withContext(Dispatchers.IO) {
        try {
            val remoteFileId = findDictionaryFileId(accessToken)
            val remoteEntries = if (remoteFileId != null) {
                downloadDictionary(accessToken, remoteFileId)
            } else {
                emptyList()
            }

            val localEntries = dictionaryDao.getAllEntriesIncludingDeleted()
            val merged = mergeEntries(localEntries, remoteEntries)

            // Save merged entries locally
            dictionaryDao.upsertAll(merged)

            // Upload merged entries back to Google Drive appDataFolder
            val payloadJson = json.encodeToString(
                DictionarySyncPayload(
                    syncedAt = System.currentTimeMillis(),
                    entries = merged
                )
            )
            uploadDictionary(accessToken, remoteFileId, payloadJson)

            val now = System.currentTimeMillis()
            val activeCount = merged.count { !it.isDeleted }
            settingsRepository.updateSyncMetadata(
                email = null,
                timestamp = now,
                status = "Synced $activeCount words"
            )
            SyncResult.Success(activeCount)
        } catch (e: Exception) {
            val msg = e.message ?: "Unknown Drive sync error"
            settingsRepository.updateSyncMetadata(null, null, "Sync error: $msg")
            SyncResult.Failure(msg)
        }
    }

    private fun mergeEntries(
        local: List<DictionaryEntry>,
        remote: List<DictionaryEntry>
    ): List<DictionaryEntry> {
        val byId = LinkedHashMap<String, DictionaryEntry>()
        for (entry in remote) {
            byId[entry.id] = entry
        }
        for (entry in local) {
            val existing = byId[entry.id]
            if (existing == null || entry.updatedAt >= existing.updatedAt) {
                byId[entry.id] = entry
            }
        }
        return byId.values.toList()
    }

    private fun findDictionaryFileId(accessToken: String): String? {
        val url = "https://www.googleapis.com/drive/v3/files" +
            "?spaces=appDataFolder&q=name%3D%27$DICTIONARY_FILENAME%27&fields=files(id,name,modifiedTime)"
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Drive list failed (${response.code})")
            }
            val body = response.body?.string().orEmpty()
            val files = json.parseToJsonElement(body).jsonObject["files"]?.jsonArray
            return files?.firstOrNull()?.jsonObject?.get("id")?.jsonPrimitive?.content
        }
    }

    private fun downloadDictionary(accessToken: String, fileId: String): List<DictionaryEntry> {
        val url = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val body = response.body?.string().orEmpty()
            if (body.isBlank()) return emptyList()
            return runCatching {
                json.decodeFromString<DictionarySyncPayload>(body).entries
            }.getOrDefault(emptyList())
        }
    }

    private fun uploadDictionary(accessToken: String, existingFileId: String?, jsonContent: String) {
        if (existingFileId != null) {
            val url = "https://www.googleapis.com/upload/drive/v3/files/$existingFileId?uploadType=media"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .patch(jsonContent.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) throw IllegalStateException("Drive update failed (${resp.code})")
            }
        } else {
            val metadata = """{"name":"$DICTIONARY_FILENAME","parents":["appDataFolder"]}"""
            val multipartBody = MultipartBody.Builder()
                .setType("multipart/related".toMediaType())
                .addPart(metadata.toRequestBody("application/json; charset=UTF-8".toMediaType()))
                .addPart(jsonContent.toRequestBody("application/json; charset=UTF-8".toMediaType()))
                .build()

            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                .addHeader("Authorization", "Bearer $accessToken")
                .post(multipartBody)
                .build()

            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) throw IllegalStateException("Drive create failed (${resp.code})")
            }
        }
    }

    private sealed class TokenResult {
        data class Success(val accessToken: String) : TokenResult()
        data class NeedsConsent(val pendingIntent: android.app.PendingIntent) : TokenResult()
        data class Error(val message: String) : TokenResult()
    }

    private suspend fun requestDriveToken(): TokenResult = suspendCancellableCoroutine { cont ->
        val authRequest = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(DRIVE_APPDATA_SCOPE)))
            .build()

        Identity.getAuthorizationClient(context)
            .authorize(authRequest)
            .addOnSuccessListener { result ->
                if (result.hasResolution()) {
                    val pendingIntent = result.pendingIntent
                    if (pendingIntent != null) {
                        cont.resume(TokenResult.NeedsConsent(pendingIntent))
                    } else {
                        cont.resume(TokenResult.Error("Google Drive authorization requires user consent."))
                    }
                } else {
                    val token = result.accessToken
                    if (!token.isNullOrBlank()) {
                        cont.resume(TokenResult.Success(token))
                    } else {
                        cont.resume(TokenResult.Error("Empty Google Drive access token."))
                    }
                }
            }
            .addOnFailureListener { e ->
                cont.resume(TokenResult.Error(e.message ?: "Google Drive sign-in not configured"))
            }
    }
}
