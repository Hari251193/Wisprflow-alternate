package com.flowfree.app.data.model

enum class AsrProvider(
    val displayName: String,
    val subtitle: String,
    val requiresApiKey: Boolean
) {
    ANDROID_ON_DEVICE(
        displayName = "Android Built-in Speech",
        subtitle = "100% Free • Offline/System • Zero API key needed",
        requiresApiKey = false
    ),
    GROQ_WHISPER_TURBO(
        displayName = "Groq Whisper Large v3 Turbo",
        subtitle = "Free Tier • Ultra-fast • 100+ languages & accents",
        requiresApiKey = true
    )
}

enum class LlmProvider(
    val displayName: String,
    val subtitle: String,
    val defaultModelId: String,
    val requiresApiKey: Boolean
) {
    LOCAL_RULES(
        displayName = "On-Device Smart Cleanup",
        subtitle = "100% Free • Offline • Instant filler removal & dictionary",
        defaultModelId = "local-rules-v1",
        requiresApiKey = false
    ),
    GEMINI_FREE(
        displayName = "Google Gemini (Free Tier)",
        subtitle = "Free Google AI Studio key • Best punctuation & context",
        defaultModelId = "gemini-2.5-flash",
        requiresApiKey = true
    ),
    GROQ_FREE(
        displayName = "Groq Llama 3.3 70B (Free Tier)",
        subtitle = "Free Groq key • Sub-second AI rewriting",
        defaultModelId = "llama-3.3-70b-versatile",
        requiresApiKey = true
    ),
    OPENROUTER_FREE(
        displayName = "OpenRouter (:free models)",
        subtitle = "Free OpenRouter key • Gemma 3 / Llama 3.3 :free",
        defaultModelId = "meta-llama/llama-3.3-70b-instruct:free",
        requiresApiKey = true
    )
}

enum class WritingTone(val displayName: String, val instruction: String) {
    NATURAL("Natural & Clean", "Keep the speaker's natural voice, fix punctuation, remove filler words (um, uh, like, you know), and apply self-corrections."),
    PROFESSIONAL("Professional", "Polish into crisp, clear professional prose suitable for work emails and Slack/Teams messages."),
    CASUAL("Casual Chat", "Keep it friendly, concise, and conversational for WhatsApp or SMS."),
    BULLET_NOTES("Structured Notes", "Format into concise bullet points or numbered lists whenever multiple items or steps are mentioned.")
}

enum class BubbleStyle(val displayName: String) {
    COMPACT_DOT("Small Edge Dot"),
    PILL("Compact Pill")
}

data class AppSettings(
    val asrProvider: AsrProvider = AsrProvider.ANDROID_ON_DEVICE,
    val llmProvider: LlmProvider = LlmProvider.LOCAL_RULES,
    val geminiApiKey: String = "",
    val geminiModelId: String = LlmProvider.GEMINI_FREE.defaultModelId,
    val groqApiKey: String = "",
    val groqModelId: String = LlmProvider.GROQ_FREE.defaultModelId,
    val openRouterApiKey: String = "",
    val openRouterModelId: String = LlmProvider.OPENROUTER_FREE.defaultModelId,
    val writingTone: WritingTone = WritingTone.NATURAL,
    val languageCode: String = "en-IN",
    val autoSyncDrive: Boolean = true,
    val lastSyncTimestamp: Long = 0L,
    val driveAccountEmail: String = "",
    val lastSyncStatus: String = "Not synced yet",
    // Floating bubble customization
    val bubbleStyle: BubbleStyle = BubbleStyle.COMPACT_DOT,
    val bubbleSizeDp: Int = 28,
    val bubbleIdleOpacity: Float = 0.65f,
    val bubbleColorHex: String = "#38BDF8",
    val bubbleSnapToEdge: Boolean = true
)
