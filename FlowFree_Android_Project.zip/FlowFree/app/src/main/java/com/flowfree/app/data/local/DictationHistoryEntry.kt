package com.flowfree.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dictation_history")
data class DictationHistoryEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val rawTranscript: String,
    val polishedText: String,
    val asrUsed: String,
    val llmUsed: String,
    val targetAppPackage: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
