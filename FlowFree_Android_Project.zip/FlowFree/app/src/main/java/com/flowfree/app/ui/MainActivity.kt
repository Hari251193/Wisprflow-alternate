package com.flowfree.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.flowfree.app.data.local.DictionaryEntry
import com.flowfree.app.data.model.AppSettings
import com.flowfree.app.data.model.AsrProvider
import com.flowfree.app.data.model.BubbleStyle
import com.flowfree.app.data.model.LlmProvider
import com.flowfree.app.data.model.WritingTone
import com.flowfree.app.service.FloatingBubbleService
import com.flowfree.app.service.FlowAccessibilityService
import com.flowfree.app.ui.theme.FlowFreeTheme
import com.google.android.gms.auth.api.identity.Identity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FlowFreeTheme {
                FlowFreeAppScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlowFreeAppScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val dictionary by viewModel.dictionaryEntries.collectAsState()
    val history by viewModel.recentHistory.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTab by remember { mutableIntStateOf(0) }

    val driveAuthLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val authResult = Identity.getAuthorizationClient(context)
            .getAuthorizationResultFromIntent(result.data)
        val token = authResult.accessToken
        if (!token.isNullOrBlank()) {
            viewModel.completeDriveSyncWithToken(token)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.uiMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.driveConsentEvent.collect { pendingIntent ->
            driveAuthLauncher.launch(IntentSenderRequest.Builder(pendingIntent).build())
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("FlowFree", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { viewModel.syncDriveNow() }) {
                        Icon(Icons.Default.CloudSync, contentDescription = "Sync Drive")
                        Spacer(Modifier.width(4.dp))
                        Text(if (isSyncing) "Syncing..." else "Sync")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Book, contentDescription = "Dictionary") },
                    label = { Text("Dictionary") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Tune, contentDescription = "Models") },
                    label = { Text("Models") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Test") },
                    label = { Text("Test") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> HomeTab(settings, history, viewModel, onClearHistory = { viewModel.clearHistory() })
                1 -> DictionaryTab(
                    entries = dictionary,
                    settings = settings,
                    isSyncing = isSyncing,
                    onAddOrUpdate = { w, a, c, id -> viewModel.addOrUpdateWord(w, a, c, id) },
                    onDelete = { viewModel.deleteWord(it) },
                    onToggleAutoSync = { viewModel.setAutoSyncDrive(it) },
                    onSyncNow = { viewModel.syncDriveNow() }
                )
                2 -> ModelsTab(settings, viewModel)
                3 -> TestSandboxTab(viewModel)
            }
        }
    }
}

@Composable
fun HomeTab(
    settings: AppSettings,
    history: List<com.flowfree.app.data.local.DictationHistoryEntry>,
    viewModel: MainViewModel,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    var micGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var overlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var accessibilityGranted by remember { mutableStateOf(FlowAccessibilityService.instance != null) }
    var bubbleRunning by remember { mutableStateOf(FloatingBubbleService.isRunning) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        micGranted = results[Manifest.permission.RECORD_AUDIO] ?: micGranted
    }

    val colorSwatches = listOf(
        "#38BDF8" to "Sky",
        "#10B981" to "Emerald",
        "#A855F7" to "Violet",
        "#F59E0B" to "Amber",
        "#F43F5E" to "Rose",
        "#E4E4E7" to "Silver"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Floating Dictation Bubble", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Active stack: ${settings.asrProvider.displayName} + ${settings.llmProvider.displayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                overlayGranted = Settings.canDrawOverlays(context)
                                if (!micGranted) {
                                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    permissionLauncher.launch(perms.toTypedArray())
                                    return@Button
                                }
                                if (!overlayGranted) {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                    return@Button
                                }
                                val serviceIntent = Intent(context, FloatingBubbleService::class.java)
                                if (bubbleRunning) {
                                    context.stopService(serviceIntent)
                                    bubbleRunning = false
                                } else {
                                    ContextCompat.startForegroundService(context, serviceIntent)
                                    bubbleRunning = true
                                }
                            },
                            colors = if (bubbleRunning) {
                                ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            } else {
                                ButtonDefaults.buttonColors()
                            }
                        ) {
                            Icon(
                                if (bubbleRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(if (bubbleRunning) "Stop Bubble" else "Start Floating Bubble")
                        }
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Bubble Appearance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        // Live dot preview
                        val previewColor = Color(android.graphics.Color.parseColor(settings.bubbleColorHex))
                        Box(
                            modifier = Modifier
                                .size(settings.bubbleSizeDp.dp)
                                .alpha(settings.bubbleIdleOpacity)
                                .clip(CircleShape)
                                .background(previewColor)
                                .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BubbleStyle.entries.forEach { style ->
                            FilterChip(
                                selected = settings.bubbleStyle == style,
                                onClick = { viewModel.setBubbleStyle(style) },
                                label = { Text(style.displayName) }
                            )
                        }
                    }

                    Text(
                        "Idle Opacity: ${(settings.bubbleIdleOpacity * 100).roundToInt()}%",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = settings.bubbleIdleOpacity,
                        onValueChange = { viewModel.setBubbleIdleOpacity(it) },
                        valueRange = 0.2f..1.0f
                    )

                    if (settings.bubbleStyle == BubbleStyle.COMPACT_DOT) {
                        Text(
                            "Dot Size: ${settings.bubbleSizeDp} dp",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = settings.bubbleSizeDp.toFloat(),
                            onValueChange = { viewModel.setBubbleSizeDp(it.roundToInt()) },
                            valueRange = 18f..52f
                        )
                    }

                    Text("Dot Accent Color", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        colorSwatches.forEach { (hex, _) ->
                            val swatchColor = Color(android.graphics.Color.parseColor(hex))
                            val selected = settings.bubbleColorHex.equals(hex, ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(swatchColor)
                                    .border(
                                        width = if (selected) 3.dp else 1.dp,
                                        color = if (selected) Color.White else Color.Gray,
                                        shape = CircleShape
                                    )
                                    .clickable { viewModel.setBubbleColorHex(hex) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Snap to nearest screen edge", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = settings.bubbleSnapToEdge,
                            onCheckedChange = { viewModel.setBubbleSnapToEdge(it) }
                        )
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Setup Checklist", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    PermissionRow("1. Microphone Access", micGranted) {
                        permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                    }
                    PermissionRow("2. Display Over Other Apps", overlayGranted) {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    }
                    PermissionRow("3. Accessibility Auto-Paste", accessibilityGranted) {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    TextButton(onClick = {
                        micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        overlayGranted = Settings.canDrawOverlays(context)
                        accessibilityGranted = FlowAccessibilityService.instance != null
                        bubbleRunning = FloatingBubbleService.isRunning
                    }) {
                        Text("Refresh Status")
                    }
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recent Dictations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) {
                    TextButton(onClick = onClearHistory) { Text("Clear") }
                }
            }
        }

        if (history.isEmpty()) {
            item {
                Text(
                    "No dictations yet. Start the floating dot and tap it inside WhatsApp, Gmail, or any app.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(history) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(item.polishedText, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${item.asrUsed} • ${item.llmUsed}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(label: String, granted: Boolean, onGrant: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            )
            Spacer(Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
        if (!granted) {
            OutlinedButton(onClick = onGrant) { Text("Enable") }
        } else {
            Text("Ready", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun DictionaryTab(
    entries: List<DictionaryEntry>,
    settings: AppSettings,
    isSyncing: Boolean,
    onAddOrUpdate: (String, String, String, String?) -> Unit,
    onDelete: (String) -> Unit,
    onToggleAutoSync: (Boolean) -> Unit,
    onSyncNow: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<DictionaryEntry?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Google Drive Auto-Sync", fontWeight = FontWeight.Bold)
                                Text(
                                    settings.lastSyncStatus,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (settings.lastSyncTimestamp > 0) {
                                    val formatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                                        .format(Date(settings.lastSyncTimestamp))
                                    Text(
                                        "Last synced: $formatted",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Switch(checked = settings.autoSyncDrive, onCheckedChange = onToggleAutoSync)
                        }
                        OutlinedButton(onClick = onSyncNow, enabled = !isSyncing) {
                            Icon(Icons.Default.CloudSync, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (isSyncing) "Syncing..." else "Sync Now")
                        }
                    }
                }
            }

            items(entries, key = { it.id }) { entry ->
                Card(
                    onClick = {
                        editingEntry = entry
                        showDialog = true
                    },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.word, fontWeight = FontWeight.SemiBold)
                            if (entry.aliases.isNotBlank()) {
                                Text(
                                    "Replaces: ${entry.aliases}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                entry.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { onDelete(entry.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }

        FloatingActionButton(
            onClick = {
                editingEntry = null
                showDialog = true
            },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Word")
        }
    }

    if (showDialog) {
        var word by remember { mutableStateOf(editingEntry?.word ?: "") }
        var aliases by remember { mutableStateOf(editingEntry?.aliases ?: "") }
        var category by remember { mutableStateOf(editingEntry?.category ?: "Names") }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(if (editingEntry == null) "Add Dictionary Word" else "Edit Word") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = word,
                        onValueChange = { word = it },
                        label = { Text("Exact Spelling (e.g. Hariprasath)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = aliases,
                        onValueChange = { aliases = it },
                        label = { Text("Misheard Aliases (comma-separated)") }
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category (Names, Work, Jargon)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onAddOrUpdate(word, aliases, category, editingEntry?.id)
                    showDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun ModelsTab(settings: AppSettings, viewModel: MainViewModel) {
    var geminiKey by remember(settings.geminiApiKey) { mutableStateOf(settings.geminiApiKey) }
    var geminiModel by remember(settings.geminiModelId) { mutableStateOf(settings.geminiModelId) }
    var groqKey by remember(settings.groqApiKey) { mutableStateOf(settings.groqApiKey) }
    var groqModel by remember(settings.groqModelId) { mutableStateOf(settings.groqModelId) }
    var openRouterKey by remember(settings.openRouterApiKey) { mutableStateOf(settings.openRouterApiKey) }
    var openRouterModel by remember(settings.openRouterModelId) { mutableStateOf(settings.openRouterModelId) }
    var languageCode by remember(settings.languageCode) { mutableStateOf(settings.languageCode) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("1. Speech-to-Text (Free)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(AsrProvider.entries) { provider ->
            Card(
                onClick = { viewModel.setAsrProvider(provider) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = settings.asrProvider == provider, onClick = { viewModel.setAsrProvider(provider) })
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(provider.displayName, fontWeight = FontWeight.SemiBold)
                        Text(provider.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Text("2. AI Text Polisher (Free)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(LlmProvider.entries) { provider ->
            Card(
                onClick = { viewModel.setLlmProvider(provider) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = settings.llmProvider == provider, onClick = { viewModel.setLlmProvider(provider) })
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(provider.displayName, fontWeight = FontWeight.SemiBold)
                        Text(provider.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Text("3. Writing Tone & Language", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            WritingTone.entries.forEach { tone ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = settings.writingTone == tone, onClick = { viewModel.setWritingTone(tone) })
                    Text(tone.displayName)
                }
            }
            OutlinedTextField(
                value = languageCode,
                onValueChange = { languageCode = it },
                label = { Text("Language Code (e.g. en-IN, en-US, ta-IN, hi-IN)") },
                modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = { viewModel.setLanguageCode(languageCode) }) { Text("Save Language") }
        }

        item {
            Text("4. Free Tier API Keys (Optional)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            ApiConfigCard(
                title = "Google Gemini (aistudio.google.com)",
                apiKey = geminiKey,
                onApiKeyChange = { geminiKey = it },
                modelId = geminiModel,
                onModelIdChange = { geminiModel = it },
                onSave = { viewModel.saveGeminiConfig(geminiKey, geminiModel) }
            )
            Spacer(Modifier.height(8.dp))
            ApiConfigCard(
                title = "Groq (console.groq.com)",
                apiKey = groqKey,
                onApiKeyChange = { groqKey = it },
                modelId = groqModel,
                onModelIdChange = { groqModel = it },
                onSave = { viewModel.saveGroqConfig(groqKey, groqModel) }
            )
            Spacer(Modifier.height(8.dp))
            ApiConfigCard(
                title = "OpenRouter Free (openrouter.ai)",
                apiKey = openRouterKey,
                onApiKeyChange = { openRouterKey = it },
                modelId = openRouterModel,
                onModelIdChange = { openRouterModel = it },
                onSave = { viewModel.saveOpenRouterConfig(openRouterKey, openRouterModel) }
            )
        }
    }
}

@Composable
private fun ApiConfigCard(
    title: String,
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    modelId: String,
    onModelIdChange: (String) -> Unit,
    onSave: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = apiKey,
                onValueChange = onApiKeyChange,
                label = { Text("API Key") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = modelId,
                onValueChange = onModelIdChange,
                label = { Text("Model ID") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = onSave) { Text("Save") }
        }
    }
}

@Composable
fun TestSandboxTab(viewModel: MainViewModel) {
    var rawText by remember {
        mutableStateOf("um hey team lets meet at 2 actually 3 pm to review the wita deck with harry prasad")
    }
    var polishedOutput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Test AI Polish & Dictionary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = rawText,
            onValueChange = { rawText = it },
            label = { Text("Raw Speech or Dictate Here with Floating Bubble") },
            minLines = 4,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { viewModel.testPolishText(rawText) { polishedOutput = it } }) {
            Icon(Icons.Default.Mic, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Run Polish + Dictionary")
        }
        if (polishedOutput.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Polished Output", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Text(polishedOutput, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
