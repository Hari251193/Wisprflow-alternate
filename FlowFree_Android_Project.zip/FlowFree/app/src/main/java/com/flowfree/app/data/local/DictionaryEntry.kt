package com.flowfree.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
@Entity(tableName = "dictionary_entries")
data class DictionaryEntry(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val word: String,
    val aliases: String = "", // Comma-separated misheard variants, e.g. "hari prasath, harry prasad"
    val category: String = "General",
    val updatedAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false
)
