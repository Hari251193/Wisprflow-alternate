# FlowFree — Free Wispr Flow Alternative for Android

FlowFree is an open-source, zero-subscription Android voice-to-text dictation app modeled after Wispr Flow. It gives you a **floating mic bubble** that works in any app (WhatsApp, Gmail, Slack, Notes), **100% free & free-tier AI models**, a **personal dictionary**, and **automatic Google Drive sync**.

## Features
- **Floating Mic Bubble + Accessibility Insertion**: Dictate into any text field across Android without switching keyboards.
- **Zero-Cost Model Choices**:
  - **100% Offline / Zero-Key Mode**: Android Built-in SpeechRecognizer + On-Device Smart Cleanup (removes `um/uh`, fixes capitalization/punctuation, applies self-corrections & dictionary aliases).
  - **Free Cloud Tier (BYOK)**:
    - **ASR**: Groq `whisper-large-v3-turbo` (free key from `console.groq.com`) for ultra-fast multilingual & Indian-English accuracy.
    - **AI Polisher**: Google Gemini (`gemini-2.5-flash` via `aistudio.google.com`), Groq Llama 3.3 70B, or OpenRouter `:free` models.
- **Personal Dictionary + Auto Google Drive Sync**:
  - Store exact spellings (names, company jargon, acronyms) and misheard aliases.
  - Automatically syncs `flowfree_dictionary.json` to your private Google Drive `appDataFolder` via `WorkManager` (on every edit + every 6 hours) with timestamp-based conflict merging.

## Build & Setup in Android Studio
1. Unzip `FlowFree_Android_Project.zip` and open the `FlowFree` folder in **Android Studio** (Ladybug or newer).
2. Let Gradle sync (uses Kotlin 2.0, Jetpack Compose Material 3, Room, DataStore, WorkManager, OkHttp).
3. **For Google Drive Auto-Sync**:
   - Go to [Google Cloud Console](https://console.cloud.google.com/) → create a free project → enable **Google Drive API**.
   - Under **APIs & Services → Credentials**, create an **OAuth 2.0 Client ID** of type **Android**:
     - Package name: `com.flowfree.app`
     - SHA-1 fingerprint: run `./gradlew signingReport` in Android Studio Terminal and paste the debug SHA-1.
   - No client secret or backend server is required!
4. Run on your Android phone (Android 8.0+ / API 26+), grant **Microphone**, **Display over other apps**, and **Accessibility** permissions on the Home tab, and tap **Start Floating Bubble**.
